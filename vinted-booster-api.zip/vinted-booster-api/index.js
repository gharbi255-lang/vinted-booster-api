import express from "express";
import cors from "cors";
import fetch from "node-fetch";

const app = express();
app.use(cors());
app.use(express.json({ limit: "10mb" }));

// 🔑 Clé API dans les variables d'environnement (NE JAMAIS l'écrire en dur)
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

// Petit log si la clé manque
if (!OPENAI_API_KEY) {
  console.error("❌ ERREUR : aucune clé OPENAI_API_KEY définie dans Replit.");
}

// Petit endpoint de test
app.get("/", (req, res) => {
  res.send("Vinted Booster API OK ✅");
});

// 🧠 Endpoint Vision : analyse une image et renvoie un JSON (titre, description, prix, etc.)
app.post("/api/vision", async (req, res) => {
  try {
    const { image } = req.body;

    if (!image) {
      return res.status(400).json({ error: "Image manquante." });
    }

    const promptText = `
Tu analyses une photo d'un article à vendre sur Vinted.

1) Décris ce que tu vois (type d'article, vêtement ou objet, style).
2) Propose un Titre efficace pour une annonce Vinted en français.
3) Propose une Description courte (3 à 5 phrases), honnête et rassurante.
4) Estime l'état : "Neuf", "Comme neuf", "Très bon état", "Bon état", "État correct".
5) Donne une catégorie simple : "Vêtements", "Chaussures", "Accessoires", "Électronique", "Maison", "Autre".
6) Donne la couleur principale (en français).
7) Si visible, donne la marque.
8) Suggère un prix de vente d'occasion en euros, adapté à Vinted (nombre entier).

Réponds OBLIGATOIREMENT en JSON valide, format exact :
{
  "title": "Titre de l'annonce",
  "description": "Description de l'annonce",
  "state": "Très bon état",
  "category": "Vêtements",
  "color": "noir",
  "brand": "Nike",
  "price": 35
}
`.trim();

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        response_format: { type: "json_object" },
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: promptText,
              },
              {
                type: "image_url",
                image_url: {
                  url: image,
                },
              },
            ],
          },
        ],
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error("Erreur API OpenAI :", response.status, errText);
      return res
        .status(500)
        .json({ error: "Erreur API OpenAI", status: response.status });
    }

    const data = await response.json();
    const raw = data.choices?.[0]?.message?.content;

    if (!raw) {
      console.error("Réponse IA vide ou inattendue :", data);
      return res.status(500).json({ error: "Réponse IA vide ou invalide." });
    }

    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (e) {
      console.error("JSON IA invalide :", raw);
      return res.status(500).json({ error: "JSON IA invalide." });
    }

    // On renvoie directement le JSON propre au frontend (extension)
    return res.json({
      title: parsed.title || "",
      description: parsed.description || "",
      state: parsed.state || "",
      category: parsed.category || "",
      color: parsed.color || "",
      brand: parsed.brand || "",
      price: parsed.price || null,
    });
  } catch (err) {
    console.error("Erreur serveur /api/vision :", err);
    return res.status(500).json({ error: "Erreur serveur." });
  }
});

// 🚀 Lancer le serveur
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Vinted Booster API en ligne sur le port ${PORT}`);
});
